import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Timer from './Timer';
import TodoApp from './TodoApp';
import MarkdownEditor from './MarkDownEditor';

import * as serviceWorker from './serviceWorker';

ReactDOM.render( 
  <React.StrictMode >
    <App / >
  </React.StrictMode>,
  document.getElementById('root')
);

ReactDOM.render( 
  <React.StrictMode >
    <Timer / >
  </React.StrictMode>,
  document.getElementById('timer-example')
);

ReactDOM.render( 
  <React.StrictMode >
    <TodoApp / >
  </React.StrictMode>,
  document.getElementById('todos-example')
);


ReactDOM.render( 
  <React.StrictMode >
    <MarkdownEditor / >
  </React.StrictMode>,
  document.getElementById('markdown-example')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();