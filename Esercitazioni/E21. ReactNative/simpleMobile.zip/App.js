import React from 'react';
// Componenti UI React Native
import { Image, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

// Moduli per accesso a funzionalità del dispositivo
import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';

// gestione del upload dei file su anonymousfiles.io
import uploadToAnonymousFilesAsync from 'anonymous-files'; 

// importazione del logo dagli asset del progetto
import logo from './assets/logo.png'; 

export default function App() {
  const [selectedImage, setSelectedImage] = React.useState(null);

  // Callback di accesso alla photo gallery e selezione dell'immagine
  let openImagePickerAsync = async () => {
    let permissionResult = await ImagePicker.requestCameraRollPermissionsAsync();
    // verifica permessi di accesso alla gallery
    if (permissionResult.granted === false) {
      alert("Permission to access camera roll is required!");
      return;
    }

    let pickerResult = await ImagePicker.launchImageLibraryAsync();
    if (pickerResult.cancelled === true) {
      return; // operazione abortita
    }

    if (Platform.OS === 'web') {
      // i browser web non possono condividere una URI locale per motivi di sicurezza
      // facciamo un upload fittizio su anonymousfile.io e ricaviamo la URI remota del file
      let remoteUri = await uploadToAnonymousFilesAsync(pickerResult.uri);
      setSelectedImage({ localUri: pickerResult.uri, remoteUri });
    } else {
      // remoteUri è null per un device mobile
      setSelectedImage({ localUri: pickerResult.uri, remoteUri: null });
    } 
  };

  // Callback di invocazione del widget di sharing
  let openShareDialogAsync = async () => {
    if (!(await Sharing.isAvailableAsync())) {
      alert(`The image is available for sharing at: ${selectedImage.remoteUri}`);
      
      return;
    }

    Sharing.shareAsync(selectedImage.localUri);
  };
  
  // Mostra l'immagine se è stata selezionata
  // e sotto posiziona il pulsante per lo sharing
  if (selectedImage !== null) {
    return (
      <View style={styles.container}>
        <Image
          source={{ uri: selectedImage.localUri }}
          style={styles.thumbnail}
        />

        <TouchableOpacity onPress={openShareDialogAsync} style={styles.button}>
          <Text style={styles.buttonText}>Share this photo</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    // Schermata home dell'applicazione
    // Logo, Messaggio di benvenuto e pulsante per selezionare la foto
    <View style={styles.container}>
      <Image source={{
        logo
        // potremmo usare uri: "https://percorso/verso/una-immagine.png" per caricare
        // l'icona in remoto
        }} style={styles.logo}  />
    
      <Text style={styles.instructions} >
        To share a photo from your phone with a friend, just press the button below!
      </Text>

      <TouchableOpacity
        onPress={openImagePickerAsync}
        style={styles.button}>
        <Text style={styles.buttonText}>Pick a photo</Text>
      </TouchableOpacity>
    </View>
  );
}

// Creazione dell'oggetto contenente lo stile
// ogni proprietà dell'oggetto è una classe CSS
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 305,
    height: 159,
    marginBottom: 10,
  },
  instructions: {
    color: '#888',
    fontSize: 18,
    marginHorizontal: 15,
  },
  button: {
    backgroundColor: "blue",
    padding: 20,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 20,
    color: '#fff',
  },
  thumbnail: {
    width: 300,
    height: 300,
    resizeMode: "contain"
  }
});
